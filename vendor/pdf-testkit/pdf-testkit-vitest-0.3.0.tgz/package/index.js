// packages/vitest/src/index.ts
import { expect } from "vitest";

// packages/matcher-core/dist/toMatchPDFSnapshot.js
import { readFile as readFile2 } from "node:fs/promises";
import { access } from "node:fs/promises";

// packages/core/dist/events.js
var DEFAULT_SEVERITY = {
  "page-count-changed": "error",
  "heading-hierarchy-changed": "error",
  "text-overflowed-container": "error",
  "element-moved-to-different-page": "warn",
  "table-moved": "warn",
  "element-added": "warn",
  "element-removed": "warn"
};
var DEFAULT_POSITION_THRESHOLD_PTS = 24;

// packages/core/dist/geometry.js
function round1(n) {
  return Math.round((n + Number.EPSILON) * 10) / 10;
}
function roundBBox(b) {
  return { x: round1(b.x), y: round1(b.y), width: round1(b.width), height: round1(b.height) };
}
function centerDistance(a, b) {
  const ax = a.x + a.width / 2;
  const ay = a.y + a.height / 2;
  const bx = b.x + b.width / 2;
  const by = b.y + b.height / 2;
  return Math.hypot(ax - bx, ay - by);
}
function computeOverflow(node, container, kind, tol = 0.5) {
  const overRight = node.x + node.width - (container.x + container.width);
  const overBottom = node.y + node.height - (container.y + container.height);
  const overLeft = container.x - node.x;
  const overTop = container.y - node.y;
  const xOver = Math.max(overRight, overLeft, 0);
  const yOver = Math.max(overBottom, overTop, 0);
  if (xOver <= tol && yOver <= tol)
    return null;
  const axis = xOver > tol && yOver > tol ? "both" : xOver > tol ? "x" : "y";
  return { axis, overflowPts: round1(Math.max(xOver, yOver)), container: kind };
}
function median(values) {
  if (values.length === 0)
    return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

// packages/core/dist/text/headingLevels.js
function buildHeadingLevelMap(sizes) {
  const tiers = clusterTiers(sizes);
  return (size) => {
    if (tiers.length === 0)
      return 1;
    let bestI = 0;
    let bestD = Infinity;
    for (let i = 0; i < tiers.length; i++) {
      const d = Math.abs(tiers[i] - size);
      if (d < bestD) {
        bestD = d;
        bestI = i;
      }
    }
    return Math.min(bestI + 1, 6);
  };
}
function clusterTiers(sizes) {
  const uniq = [...new Set(sizes.map(round1))].sort((a, b) => b - a);
  const tiers = [];
  for (const s of uniq) {
    const last = tiers[tiers.length - 1];
    if (last !== void 0 && Math.abs(last - s) <= 0.5)
      continue;
    tiers.push(s);
  }
  return tiers;
}

// packages/core/dist/text/normalize.js
function normalizeText(raw) {
  if (raw == null)
    return null;
  const collapsed = raw.replace(/\s+/g, " ").trim().toLowerCase();
  return collapsed.length === 0 ? null : collapsed;
}
function textPreview(raw, max = 40) {
  if (!raw)
    return "";
  const oneLine = raw.replace(/\s+/g, " ").trim();
  return oneLine.length <= max ? oneLine : oneLine.slice(0, max - 1) + "\u2026";
}
function textSimilarity(a, b) {
  if (a === b)
    return 1;
  if (a.length === 0 || b.length === 0)
    return 0;
  const jac = jaccard(tokens(a), tokens(b));
  const lev = 1 - levenshtein(a, b) / Math.max(a.length, b.length);
  return Math.max(0, 0.5 * jac + 0.5 * lev);
}
function tokens(s) {
  return new Set(s.split(/\s+/).filter(Boolean));
}
function jaccard(a, b) {
  if (a.size === 0 && b.size === 0)
    return 1;
  let inter = 0;
  for (const t of a)
    if (b.has(t))
      inter++;
  return inter / (a.size + b.size - inter);
}
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  let prev = new Array(n + 1).fill(0);
  let curr = new Array(n + 1).fill(0);
  for (let j = 0; j <= n; j++)
    prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
      const del = prev[j] + 1;
      const ins = curr[j - 1] + 1;
      const sub = prev[j - 1] + cost;
      curr[j] = Math.min(del, ins, sub);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

// packages/core/dist/snapshot/serialize.js
import { createHash } from "node:crypto";
function stableStringify(value) {
  return JSON.stringify(sortKeys(value));
}
function sortKeys(value) {
  if (Array.isArray(value))
    return value.map(sortKeys);
  if (value && typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      out[key] = sortKeys(value[key]);
    }
    return out;
  }
  return value;
}
function computeContentHash(snapshot) {
  const { createdAt: _createdAt, source: _source, contentHash: _hash, ...rest } = snapshot;
  return "sha256:" + createHash("sha256").update(stableStringify(rest)).digest("hex");
}
function serializeSnapshot(snapshot, pretty = true) {
  return JSON.stringify(snapshot, null, pretty ? 2 : void 0);
}

// packages/core/dist/extract/finalize.js
function finalize(producer, rawPages, rawNodes, opts) {
  const pages = [...rawPages].sort((a, b) => a.index - b.index);
  const finalIdByTemp = /* @__PURE__ */ new Map();
  const ordered = [];
  const orderByTemp = /* @__PURE__ */ new Map();
  const nodeIdsByPage = /* @__PURE__ */ new Map();
  for (const page of pages) {
    const pageNodes = rawNodes.filter((n) => n.pageIndex === page.index);
    const rowTol = readingRowTolerance(pageNodes);
    const band = (y) => Math.round(y / rowTol);
    pageNodes.sort((a, b) => band(a.bbox.y) - band(b.bbox.y) || a.bbox.x - b.bbox.x);
    const ordinalByRole = /* @__PURE__ */ new Map();
    const ids = [];
    pageNodes.forEach((node, i) => {
      const ordinal = ordinalByRole.get(node.role) ?? 0;
      ordinalByRole.set(node.role, ordinal + 1);
      const id = `${page.index}:${node.role}:${ordinal}`;
      finalIdByTemp.set(node.tempId, id);
      orderByTemp.set(node.tempId, i);
      ids.push(id);
      ordered.push(node);
    });
    nodeIdsByPage.set(page.index, ids);
  }
  const nodes = ordered.map((raw) => {
    const id = finalIdByTemp.get(raw.tempId);
    const parentId = raw.parentTempId != null ? finalIdByTemp.get(raw.parentTempId) ?? null : null;
    const node = {
      id,
      role: raw.role,
      pageIndex: raw.pageIndex,
      bbox: roundBBox(raw.bbox),
      order: orderByTemp.get(raw.tempId) ?? 0,
      parentId,
      text: raw.text,
      normText: normalizeText(raw.text),
      font: raw.font ? { ...raw.font, size: raw.font.size == null ? null : round1(raw.font.size) } : null,
      headingLevel: raw.headingLevel,
      overflow: raw.overflow,
      confidence: raw.confidence
    };
    if (raw.table)
      node.table = raw.table;
    return node;
  });
  const pageSnapshots = pages.map((p) => ({
    index: p.index,
    width: round1(p.width),
    height: round1(p.height),
    contentBox: roundBBox(p.contentBox),
    nodeIds: nodeIdsByPage.get(p.index) ?? []
  }));
  const withoutHash = {
    version: 1,
    producer,
    createdAt: opts?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    ...opts?.source ? { source: opts.source } : {},
    pageCount: pageSnapshots.length,
    pages: pageSnapshots,
    nodes
  };
  return { ...withoutHash, contentHash: computeContentHash(withoutHash) };
}
function readingRowTolerance(nodes) {
  const heights = nodes.filter((n) => n.role === "text" || n.role === "heading" || n.role === "cell").map((n) => n.font?.size ?? n.bbox.height).filter((h) => h > 0);
  if (heights.length === 0)
    return 6;
  return Math.max(2, 0.5 * median(heights));
}

// packages/core/dist/extract/fromFormeLayout.js
function roleFor(nodeType) {
  if (/^H[1-6]$/.test(nodeType) || nodeType === "Heading")
    return "heading";
  switch (nodeType) {
    case "Table":
      return "table";
    case "TableRow":
    case "Row":
      return "row";
    case "TableCell":
    case "Cell":
      return "cell";
    case "Text":
    case "TextLine":
      return "text";
    case "Image":
      return "image";
    default:
      return "container";
  }
}
function explicitLevel(nodeType) {
  const m = /^H([1-6])$/.exec(nodeType);
  return m ? Number(m[1]) : null;
}
function isTextLeaf(role) {
  return role === "heading" || role === "text" || role === "cell";
}
function fromFormeLayout(layout, opts) {
  const rawPages = [];
  const rawNodes = [];
  let counter = 0;
  const nextId = () => `f${counter++}`;
  const headingSizes = [];
  for (const page of layout.pages) {
    walk(page.elements, (el) => {
      if (roleFor(el.nodeType) === "heading" && explicitLevel(el.nodeType) == null && el.style?.fontSize) {
        headingSizes.push(el.style.fontSize);
      }
    });
  }
  const levelFor = buildHeadingLevelMap(headingSizes);
  layout.pages.forEach((page, pageIndex) => {
    const contentBox = {
      x: page.contentX,
      y: page.contentY,
      width: page.contentWidth,
      height: page.contentHeight
    };
    rawPages.push({ index: pageIndex, width: page.width, height: page.height, contentBox });
    const emit = (el, parentTempId, parentBBox) => {
      const role = roleFor(el.nodeType);
      const tempId = nextId();
      const bbox = { x: el.x, y: el.y, width: el.width, height: el.height };
      let overflow = null;
      if (role === "text" || role === "heading") {
        overflow = computeOverflow(bbox, contentBox, "page-content");
      } else if (role === "cell" && parentBBox) {
        overflow = computeOverflow(bbox, parentBBox, "parent");
      }
      const node = {
        tempId,
        parentTempId,
        role,
        pageIndex,
        bbox,
        text: isTextLeaf(role) ? collectText(el) : null,
        font: fontFrom(el.style),
        headingLevel: role === "heading" ? explicitLevel(el.nodeType) ?? levelFor(el.style?.fontSize ?? 0) : null,
        overflow,
        confidence: 1
      };
      if (role === "table")
        node.table = tableShape(el.children ?? []);
      rawNodes.push(node);
      if (!isTextLeaf(role)) {
        processChildren(el.children ?? [], tempId, bbox, role === "table");
      }
    };
    const processChildren = (children, parentTempId, parentBBox, parentIsTable) => {
      let i = 0;
      while (i < children.length) {
        const el = children[i];
        if (roleFor(el.nodeType) === "row" && !parentIsTable) {
          const run = [];
          let j = i;
          while (j < children.length && roleFor(children[j].nodeType) === "row") {
            run.push(children[j]);
            j++;
          }
          const tableTempId = nextId();
          const bbox = unionBBox(run);
          rawNodes.push({
            tempId: tableTempId,
            parentTempId,
            role: "table",
            pageIndex,
            bbox,
            text: null,
            font: null,
            headingLevel: null,
            overflow: null,
            table: tableShape(run),
            confidence: 1
          });
          for (const row of run)
            emit(row, tableTempId, bbox);
          i = j;
          continue;
        }
        emit(el, parentTempId, parentBBox);
        i++;
      }
    };
    processChildren(page.elements, null, null, false);
  });
  const snapshot = finalize("formepdf", rawPages, rawNodes, opts);
  if (opts?.assertShape !== false)
    assertShapeRecognized(layout, snapshot);
  return snapshot;
}
var FormeShapeError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "FormeShapeError";
  }
};
function assertShapeRecognized(layout, snapshot) {
  const fragments = [];
  const nodeTypesSeen = /* @__PURE__ */ new Set();
  let hasRow = false;
  let hasCell = false;
  let hasHeading = false;
  for (const page of layout.pages) {
    walk(page.elements, (el) => {
      nodeTypesSeen.add(el.nodeType);
      if (el.nodeType === "TableRow" || el.nodeType === "Row")
        hasRow = true;
      if (el.nodeType === "TableCell" || el.nodeType === "Cell")
        hasCell = true;
      if (/^H[1-6]$/.test(el.nodeType) || el.nodeType === "Heading")
        hasHeading = true;
      if (typeof el.textContent === "string") {
        const t = el.textContent.replace(/\s+/g, " ").trim().toLowerCase();
        if (t)
          fragments.push(t);
      }
    });
  }
  const context = `Seen FormePDF nodeTypes: [${[...nodeTypesSeen].sort().join(", ")}].`;
  if (fragments.length > 0) {
    const haystack = snapshot.nodes.map((n) => n.normText ?? "").join("");
    const missing = fragments.filter((f) => !haystack.includes(f));
    if (missing.length > 0) {
      throw new FormeShapeError(`fromFormeLayout dropped ${missing.length}/${fragments.length} text fragment(s) from the FormePDF layout (e.g. ${JSON.stringify(missing.slice(0, 3))}). The layout node shape has likely changed; the nodeType\u2192role mapping needs updating. ${context}`);
    }
  }
  const produced = new Set(snapshot.nodes.map((n) => n.role));
  if (hasRow && !produced.has("row")) {
    throw new FormeShapeError(`Layout has TableRow nodes but none were extracted as rows. ${context}`);
  }
  if (hasCell && !produced.has("cell")) {
    throw new FormeShapeError(`Layout has TableCell nodes but none were extracted as cells. ${context}`);
  }
  if (hasHeading && !produced.has("heading")) {
    throw new FormeShapeError(`Layout has H1\u2013H6/Heading nodes but none were extracted as headings. ${context}`);
  }
  for (const node of snapshot.nodes) {
    if (node.role === "table" && node.table && node.table.rows === 0) {
      throw new FormeShapeError(`Synthesized a table with zero rows \u2014 row grouping is broken. ${context}`);
    }
  }
}
function collectText(el) {
  const parts = [];
  const rec = (n) => {
    if (typeof n.textContent === "string" && n.textContent.length)
      parts.push(n.textContent);
    for (const c of n.children ?? [])
      rec(c);
  };
  rec(el);
  const text = parts.join(" ").replace(/\s+/g, " ").trim();
  return text.length ? text : null;
}
function fontFrom(style) {
  if (!style)
    return null;
  if (style.fontSize == null && style.fontWeight == null && style.fontFamily == null)
    return null;
  return {
    size: style.fontSize ?? null,
    weight: style.fontWeight ?? null,
    family: style.fontFamily ?? null,
    italic: style.fontStyle ? /italic|oblique/i.test(style.fontStyle) : void 0
  };
}
function tableShape(rows) {
  const rowEls = rows.filter((c) => roleFor(c.nodeType) === "row");
  let cols = 0;
  for (const row of rowEls) {
    const cells = (row.children ?? []).filter((c) => roleFor(c.nodeType) === "cell").length;
    cols = Math.max(cols, cells);
  }
  return { rows: rowEls.length, cols };
}
function unionBBox(els) {
  const minX = Math.min(...els.map((e) => e.x));
  const maxX = Math.max(...els.map((e) => e.x + e.width));
  const minY = Math.min(...els.map((e) => e.y));
  const maxY = Math.max(...els.map((e) => e.y + e.height));
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}
function walk(elements, fn) {
  for (const el of elements) {
    fn(el);
    if (el.children?.length)
      walk(el.children, fn);
  }
}

// packages/core/dist/extract/pdfjs/loadDocument.js
var cached;
async function getPdfjs() {
  if (cached)
    return cached;
  const candidates = ["pdfjs-dist/legacy/build/pdf.mjs", "pdfjs-dist"];
  let lastErr;
  for (const spec of candidates) {
    try {
      const mod = await import(
        /* @vite-ignore */
        spec
      );
      cached = mod.getDocument ? mod : mod.default;
      if (cached?.getDocument)
        return cached;
    } catch (err) {
      lastErr = err;
    }
  }
  throw new Error(`pdf-testkit: could not load "pdfjs-dist". Install it to diff non-FormePDF PDFs (npm i pdfjs-dist). Original error: ${String(lastErr)}`);
}
async function loadDocument(data) {
  const pdfjs = await getPdfjs();
  const task = pdfjs.getDocument({
    // pdfjs transfers (detaches) the `data` buffer to its worker; copy so the
    // caller's Uint8Array stays usable and re-extraction never crashes.
    data: data.slice(),
    isEvalSupported: false,
    disableFontFace: true,
    useSystemFonts: false,
    verbosity: 0
    // errors only
  });
  return await task.promise;
}

// packages/core/dist/extract/pdfjs/textRuns.js
var BOLD_RE = /bold|black|semibold|heavy/i;
var ITALIC_RE = /italic|oblique/i;
function sanitizeFontName(name) {
  return name.replace(/^g_d\d+_/, "g_");
}
async function extractTextRuns(page) {
  const viewport = page.getViewport({ scale: 1 });
  const content = await page.getTextContent();
  const items = content.items.filter((it) => typeof it?.str === "string");
  const raw = [];
  for (const it of items) {
    if (it.str.length === 0)
      continue;
    const t = it.transform;
    const x = t[4] ?? 0;
    const yBottom = t[5] ?? 0;
    const fontSize = Math.hypot(t[2] ?? 0, t[3] ?? 0) || Math.abs(t[3] ?? 0) || it.height || 0;
    const height = it.height || fontSize;
    const width = it.width || 0;
    const fontName = sanitizeFontName(it.fontName ?? "");
    raw.push({
      x,
      y: viewport.height - (yBottom + height),
      width,
      height,
      text: it.str,
      fontSize,
      fontName,
      bold: BOLD_RE.test(fontName),
      italic: ITALIC_RE.test(fontName),
      charCount: it.str.length
    });
  }
  return { runs: mergeRuns(raw), width: viewport.width, height: viewport.height };
}
function mergeRuns(items) {
  const sorted = [...items].sort((a, b) => a.y - b.y || a.x - b.x);
  const out = [];
  for (const it of sorted) {
    const prev = out[out.length - 1];
    const sameLine = prev && Math.abs(prev.y - it.y) <= Math.max(1, prev.height * 0.4);
    const sameFont = prev && Math.abs(prev.fontSize - it.fontSize) <= 0.5;
    const gap = prev ? it.x - (prev.x + prev.width) : Infinity;
    const adjacent = prev && gap <= prev.fontSize * 0.6 && it.x >= prev.x - 0.5;
    if (prev && sameLine && sameFont && adjacent) {
      prev.text += (gap > prev.fontSize * 0.2 ? " " : "") + it.text;
      prev.width = it.x + it.width - prev.x;
      prev.charCount += it.charCount;
      prev.bold = prev.bold || it.bold;
    } else {
      out.push({ ...it });
    }
  }
  return out;
}

// packages/core/dist/extract/pdfjs/headings.js
var HEADING_RATIO = 1.15;
var BOLD_RATIO = 1.05;
function buildHeadingModel(runs) {
  const weightBySize = /* @__PURE__ */ new Map();
  for (const r of runs) {
    const s = round1(r.fontSize);
    weightBySize.set(s, (weightBySize.get(s) ?? 0) + r.charCount);
  }
  let bodySize = 0;
  let bestWeight = -1;
  for (const [size, w] of weightBySize) {
    if (w > bestWeight) {
      bestWeight = w;
      bodySize = size;
    }
  }
  const candidateSizes = [
    ...new Set(runs.filter((r) => r.fontSize > bodySize * HEADING_RATIO).map((r) => round1(r.fontSize)))
  ];
  const levelFor = buildHeadingLevelMap(candidateSizes);
  const sizeSeparated = (r) => r.fontSize > bodySize * HEADING_RATIO;
  const boldSeparated = (r) => r.bold && r.fontSize >= bodySize * BOLD_RATIO;
  return {
    bodySize,
    isHeading: (r) => sizeSeparated(r) || boldSeparated(r),
    levelOf: (r) => sizeSeparated(r) ? levelFor(round1(r.fontSize)) : 6,
    confidenceOf: (r) => sizeSeparated(r) ? 0.8 : 0.5
  };
}

// packages/core/dist/extract/pdfjs/tables.js
function detectTables(runs) {
  if (runs.length < 6)
    return [];
  const heights = runs.map((r) => r.height).filter((h) => h > 0);
  const rowTol = Math.max(2, 0.6 * median(heights));
  const bands = groupBands(runs, rowTol);
  if (bands.length < 3)
    return [];
  const charWidths = runs.map((r) => r.width / Math.max(1, r.text.length)).filter((w) => w > 0);
  const colTol = Math.max(4, (median(charWidths) || median(heights) * 0.5) * 2);
  const columns = clusterValues(bands.flatMap((b) => b.map((r) => r.x)), colTol);
  const colOf = (x) => nearestIndex(columns, x, colTol);
  const bandCols = bands.map((b) => new Set(b.map((r) => colOf(r.x)).filter((i2) => i2 >= 0)));
  const tables = [];
  let i = 0;
  while (i < bands.length) {
    if (bandCols[i].size < 2) {
      i++;
      continue;
    }
    let j = i;
    while (j + 1 < bands.length && bandCols[j + 1].size >= 2 && intersectionSize(bandCols[i], bandCols[j + 1]) >= 2) {
      j++;
    }
    if (j - i + 1 >= 3) {
      tables.push(buildTable(bands.slice(i, j + 1), columns, colTol));
    }
    i = j + 1;
  }
  return tables;
}
function groupBands(runs, rowTol) {
  const sorted = [...runs].sort((a, b) => a.y - b.y || a.x - b.x);
  const bands = [];
  let current = [];
  let bandY = -Infinity;
  for (const r of sorted) {
    if (current.length === 0 || Math.abs(r.y - bandY) <= rowTol) {
      current.push(r);
      bandY = current.length === 1 ? r.y : bandY;
    } else {
      bands.push(current);
      current = [r];
      bandY = r.y;
    }
  }
  if (current.length)
    bands.push(current);
  return bands.map((b) => b.sort((a, c) => a.x - c.x));
}
function buildTable(bands, columns, colTol) {
  const rows = bands.map((band) => {
    const byCol = /* @__PURE__ */ new Map();
    for (const r of band) {
      const c = nearestIndex(columns, r.x, colTol);
      const key = c >= 0 ? c : columns.length + Math.round(r.x);
      const bucket = byCol.get(key);
      if (bucket)
        bucket.push(r);
      else
        byCol.set(key, [r]);
    }
    const cells = [...byCol.entries()].sort((a, b) => a[0] - b[0]).map(([, cellRuns]) => ({
      bbox: unionBBox2(cellRuns),
      text: cellRuns.sort((a, b) => a.x - b.x).map((r) => r.text).join(" ").trim(),
      runs: cellRuns
    }));
    return { bbox: unionBBox2(band), cells };
  });
  const cols = Math.max(0, ...rows.map((r) => r.cells.length));
  return { bbox: unionBBox2(bands.flat()), rows, cols };
}
function unionBBox2(runs) {
  const minX = Math.min(...runs.map((r) => r.x));
  const maxX = Math.max(...runs.map((r) => r.x + r.width));
  const minY = Math.min(...runs.map((r) => r.y));
  const maxY = Math.max(...runs.map((r) => r.y + r.height));
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}
function clusterValues(values, tol) {
  const sorted = [...values].sort((a, b) => a - b);
  const centers = [];
  let group = [];
  for (const v of sorted) {
    const last = group[group.length - 1];
    if (last !== void 0 && v - last > tol) {
      centers.push(mean(group));
      group = [];
    }
    group.push(v);
  }
  if (group.length)
    centers.push(mean(group));
  return centers;
}
function nearestIndex(centers, x, tol) {
  let bestI = -1;
  let bestD = tol;
  for (let i = 0; i < centers.length; i++) {
    const d = Math.abs(centers[i] - x);
    if (d <= bestD) {
      bestD = d;
      bestI = i;
    }
  }
  return bestI;
}
function intersectionSize(a, b) {
  let n = 0;
  for (const v of a)
    if (b.has(v))
      n++;
  return n;
}
function mean(values) {
  return values.reduce((s, v) => s + v, 0) / values.length;
}

// packages/core/dist/extract/pdfjs/overflow.js
function inferContentBox(runs, pageWidth, pageHeight) {
  if (runs.length === 0)
    return { x: 0, y: 0, width: pageWidth, height: pageHeight };
  const minX = Math.min(...runs.map((r) => r.x));
  const maxX = Math.max(...runs.map((r) => r.x + r.width));
  const minY = Math.min(...runs.map((r) => r.y));
  const maxY = Math.max(...runs.map((r) => r.y + r.height));
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}
function buildOverflowModel(runs, pageWidth) {
  if (runs.length === 0)
    return () => null;
  const leftMargin = Math.min(...runs.map((r) => r.x));
  const rightLimit = pageWidth - leftMargin;
  return (run) => {
    const over = run.x + run.width - rightLimit;
    if (over > Math.max(2, run.fontSize)) {
      return { axis: "x", overflowPts: round1(over), container: "page-content" };
    }
    return null;
  };
}

// packages/core/dist/extract/fromPdf.js
async function fromPdf(bytes, opts) {
  const doc = await loadDocument(bytes);
  const perPage = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    perPage.push(await extractTextRuns(page));
  }
  const headingModel = buildHeadingModel(perPage.flatMap((p) => p.runs));
  const rawPages = [];
  const rawNodes = [];
  let counter = 0;
  const nextId = () => `p${counter++}`;
  perPage.forEach((pg, pageIndex) => {
    rawPages.push({
      index: pageIndex,
      width: pg.width,
      height: pg.height,
      contentBox: inferContentBox(pg.runs, pg.width, pg.height)
    });
    const overflowOf = buildOverflowModel(pg.runs, pg.width);
    const tables = detectTables(pg.runs);
    const consumed = /* @__PURE__ */ new Set();
    for (const table of tables) {
      const tableTempId = nextId();
      rawNodes.push({
        tempId: tableTempId,
        parentTempId: null,
        role: "table",
        pageIndex,
        bbox: table.bbox,
        text: null,
        font: null,
        headingLevel: null,
        overflow: null,
        table: { rows: table.rows.length, cols: table.cols },
        confidence: 0.5
      });
      for (const row of table.rows) {
        const rowTempId = nextId();
        rawNodes.push({
          tempId: rowTempId,
          parentTempId: tableTempId,
          role: "row",
          pageIndex,
          bbox: row.bbox,
          text: null,
          font: null,
          headingLevel: null,
          overflow: null,
          confidence: 0.5
        });
        for (const cell of row.cells) {
          for (const r of cell.runs)
            consumed.add(r);
          rawNodes.push({
            tempId: nextId(),
            parentTempId: rowTempId,
            role: "cell",
            pageIndex,
            bbox: cell.bbox,
            text: cell.text,
            font: fontOf(cell.runs),
            headingLevel: null,
            overflow: null,
            confidence: 0.5
          });
        }
      }
    }
    for (const r of pg.runs) {
      if (consumed.has(r))
        continue;
      const heading = headingModel.isHeading(r);
      rawNodes.push({
        tempId: nextId(),
        parentTempId: null,
        role: heading ? "heading" : "text",
        pageIndex,
        bbox: { x: r.x, y: r.y, width: r.width, height: r.height },
        text: r.text,
        font: {
          size: r.fontSize,
          weight: r.bold ? 700 : 400,
          family: r.fontName || null,
          italic: r.italic
        },
        headingLevel: heading ? headingModel.levelOf(r) : null,
        overflow: overflowOf(r),
        confidence: heading ? headingModel.confidenceOf(r) : 0.9
      });
    }
  });
  return finalize("pdfjs", rawPages, rawNodes, opts);
}
function fontOf(runs) {
  if (runs.length === 0)
    return null;
  const dominant = [...runs].sort((a, b) => b.charCount - a.charCount)[0];
  return {
    size: dominant.fontSize,
    weight: dominant.bold ? 700 : 400,
    family: dominant.fontName || null,
    italic: dominant.italic
  };
}

// packages/core/dist/diff/match.js
var FUZZY_THRESHOLD = 0.85;
var POSITION_MATCH_TOL = 4;
function matchNodes(baseNodes, nextNodes) {
  const baseLeft = new Set(baseNodes);
  const nextLeft = new Set(nextNodes);
  const pairs = [];
  const nextByKey = groupBy([...nextLeft], exactKey);
  for (const base of [...baseLeft].sort(byReadingOrder)) {
    const bucket = nextByKey.get(exactKey(base));
    if (!bucket || bucket.length === 0)
      continue;
    const next = bucket.shift();
    pairs.push({ base, next });
    baseLeft.delete(base);
    nextLeft.delete(next);
  }
  for (const base of [...baseLeft]) {
    if (!isTexty(base) || base.normText == null)
      continue;
    let best = null;
    let bestScore = FUZZY_THRESHOLD;
    for (const cand of nextLeft) {
      if (cand.role !== base.role || cand.normText == null)
        continue;
      const score = textSimilarity(base.normText, cand.normText);
      if (score >= bestScore) {
        bestScore = score;
        best = cand;
      }
    }
    if (best) {
      pairs.push({ base, next: best });
      baseLeft.delete(base);
      nextLeft.delete(best);
    }
  }
  for (const base of [...baseLeft]) {
    if (!isTexty(base))
      continue;
    let best = null;
    let bestD = POSITION_MATCH_TOL;
    for (const cand of nextLeft) {
      if (cand.role !== base.role || cand.pageIndex !== base.pageIndex)
        continue;
      const d = centerDistance(base.bbox, cand.bbox);
      if (d <= bestD) {
        bestD = d;
        best = cand;
      }
    }
    if (best) {
      pairs.push({ base, next: best });
      baseLeft.delete(base);
      nextLeft.delete(best);
    }
  }
  for (const base of [...baseLeft]) {
    if (isTexty(base))
      continue;
    let best = null;
    let bestCost = Infinity;
    for (const cand of nextLeft) {
      if (cand.role !== base.role)
        continue;
      if (!sameTableShape(base, cand))
        continue;
      const cost = Math.abs(cand.pageIndex - base.pageIndex) * 1e3 + Math.abs(cand.order - base.order);
      if (cost < bestCost) {
        bestCost = cost;
        best = cand;
      }
    }
    if (best) {
      pairs.push({ base, next: best });
      baseLeft.delete(base);
      nextLeft.delete(best);
    }
  }
  return { pairs, added: [...nextLeft], removed: [...baseLeft] };
}
function exactKey(n) {
  return `${n.role}|${n.normText ?? ""}|${n.headingLevel ?? ""}`;
}
function isTexty(n) {
  return n.role === "text" || n.role === "heading";
}
function sameTableShape(a, b) {
  if (!a.table || !b.table)
    return true;
  return a.table.rows === b.table.rows && a.table.cols === b.table.cols;
}
function byReadingOrder(a, b) {
  return a.pageIndex - b.pageIndex || a.order - b.order;
}
function groupBy(items, key) {
  const map = /* @__PURE__ */ new Map();
  for (const item of items) {
    const k = key(item);
    const bucket = map.get(k);
    if (bucket)
      bucket.push(item);
    else
      map.set(k, [item]);
  }
  for (const bucket of map.values())
    bucket.sort(byReadingOrder);
  return map;
}

// packages/core/dist/diff/diff.js
function diffSnapshots(baseline, next, opts = {}) {
  if (baseline.contentHash === next.contentHash) {
    return { changed: false, events: [], baselineHash: baseline.contentHash, newHash: next.contentHash };
  }
  const threshold = opts.positionThresholdPts ?? DEFAULT_POSITION_THRESHOLD_PTS;
  const ignore = new Set(opts.ignoreRoles ?? []);
  const minConfidence = opts.minConfidence ?? 0;
  const severityOf = (type) => opts.severityOverrides?.[type] ?? DEFAULT_SEVERITY[type];
  const baseNodes = baseline.nodes.filter((n) => !ignore.has(n.role));
  const nextNodes = next.nodes.filter((n) => !ignore.has(n.role));
  const events = [];
  if (baseline.pageCount !== next.pageCount) {
    events.push({
      type: "page-count-changed",
      severity: severityOf("page-count-changed"),
      confidence: 1,
      from: baseline.pageCount,
      to: next.pageCount,
      message: `page count changed ${baseline.pageCount} \u2192 ${next.pageCount}`
    });
  }
  const { pairs, added, removed } = matchNodes(baseNodes, nextNodes);
  for (const { base, next: after } of pairs) {
    const conf = Math.min(base.confidence, after.confidence);
    if (after.role === "table") {
      const movedPage = base.pageIndex !== after.pageIndex;
      const movedOnPage = centerDistance(base.bbox, after.bbox) > threshold;
      if (movedPage || movedOnPage) {
        events.push({
          type: "table-moved",
          severity: severityOf("table-moved"),
          confidence: conf,
          nodeId: after.id,
          fromPage: base.pageIndex,
          toPage: after.pageIndex,
          fromBBox: base.bbox,
          toBBox: after.bbox,
          message: movedPage ? `table moved from page ${base.pageIndex + 1} to page ${after.pageIndex + 1}` : `table moved ${Math.round(centerDistance(base.bbox, after.bbox))}pt on page ${after.pageIndex + 1}`
        });
      }
    } else if (base.pageIndex !== after.pageIndex) {
      events.push({
        type: "element-moved-to-different-page",
        severity: severityOf("element-moved-to-different-page"),
        confidence: conf,
        nodeId: after.id,
        role: after.role,
        textPreview: textPreview(after.text),
        fromPage: base.pageIndex,
        toPage: after.pageIndex,
        message: `${describe(after)} moved from page ${base.pageIndex + 1} to page ${after.pageIndex + 1}`
      });
    }
    if (base.role === "heading" && after.role === "heading" && base.headingLevel !== after.headingLevel) {
      events.push({
        type: "heading-hierarchy-changed",
        severity: severityOf("heading-hierarchy-changed"),
        confidence: conf,
        nodeId: after.id,
        textPreview: textPreview(after.text),
        fromLevel: base.headingLevel,
        toLevel: after.headingLevel,
        message: `heading "${textPreview(after.text)}" hierarchy changed ${fmtLevel(base.headingLevel)} \u2192 ${fmtLevel(after.headingLevel)}`
      });
    }
    if (after.overflow && !base.overflow) {
      events.push(overflowEvent(after, severityOf("text-overflowed-container"), conf));
    }
  }
  for (const node of added) {
    events.push({
      type: "element-added",
      severity: severityOf("element-added"),
      confidence: node.confidence,
      nodeId: node.id,
      role: node.role,
      textPreview: textPreview(node.text),
      pageIndex: node.pageIndex,
      message: `${describe(node)} added on page ${node.pageIndex + 1}`
    });
    if (node.overflow) {
      events.push(overflowEvent(node, severityOf("text-overflowed-container"), node.confidence));
    }
  }
  for (const node of removed) {
    events.push({
      type: "element-removed",
      severity: severityOf("element-removed"),
      confidence: node.confidence,
      role: node.role,
      textPreview: textPreview(node.text),
      pageIndex: node.pageIndex,
      message: `${describe(node)} removed from page ${node.pageIndex + 1}`
    });
  }
  const filtered = events.filter((e) => e.confidence >= minConfidence);
  return {
    changed: filtered.length > 0,
    events: filtered,
    baselineHash: baseline.contentHash,
    newHash: next.contentHash
  };
}
function overflowEvent(node, severity, confidence) {
  const o = node.overflow;
  return {
    type: "text-overflowed-container",
    severity,
    confidence,
    nodeId: node.id,
    textPreview: textPreview(node.text),
    overflow: o,
    pageIndex: node.pageIndex,
    message: `${describe(node)} overflowed its ${o.container} box by ${o.overflowPts}pt (${o.axis})`
  };
}
function describe(node) {
  const preview = textPreview(node.text);
  return preview ? `${node.role} "${preview}"` : node.role;
}
function fmtLevel(level) {
  return level == null ? "\u2014" : `H${level}`;
}

// packages/core/dist/snapshot/io.js
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
async function readSnapshotFile(path) {
  const raw = await readFile(path, "utf8");
  return JSON.parse(raw);
}
async function writeSnapshotFile(path, snapshot) {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, serializeSnapshot(snapshot) + "\n", "utf8");
}

// packages/matcher-core/dist/config.js
import { basename, dirname as dirname2, join } from "node:path";
function resolveSnapshotPath(ctx, opts) {
  const dir = opts.snapshotDir ?? join(dirname2(ctx.testPath), "__pdf_snapshots__");
  const file = basename(ctx.testPath).replace(/\.[cm]?[jt]sx?$/i, "");
  const name = slug(opts.snapshotName ?? ctx.snapshotName ?? ctx.currentTestName ?? "snapshot");
  return join(dir, `${file}-${name}.json`);
}
function isUpdateMode(ctx) {
  const env = process.env.PDF_TESTKIT_UPDATE;
  return ctx.updateMode || env === "1" || env === "true";
}
function isCI() {
  return Boolean(process.env.CI) && process.env.CI !== "false";
}
function slug(s) {
  return s.replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "snapshot";
}

// packages/matcher-core/dist/format.js
var SYMBOL = { error: "\u2717", warn: "\u26A0", info: "\u2139" };
function formatFailure(events, snapshotPath) {
  const header = `PDF snapshot changed (${events.length} semantic event${events.length === 1 ? "" : "s"}):`;
  const lines = events.map((e) => {
    const conf = e.confidence < 1 ? `  (confidence ${e.confidence.toFixed(2)})` : "";
    return `  ${SYMBOL[e.severity]} ${e.type}  ${e.message}${conf}`;
  });
  return [
    header,
    ...lines,
    "",
    "  \u2192 Run with -u (or PDF_TESTKIT_UPDATE=1) to accept these changes.",
    `  baseline: ${snapshotPath}`
  ].join("\n");
}

// packages/matcher-core/dist/toMatchPDFSnapshot.js
async function assertMatchesPDFSnapshot(received, ctx, opts = {}) {
  const snapshot = await toSnapshot(received);
  const path = resolveSnapshotPath(ctx, opts);
  const update = isUpdateMode(ctx);
  const exists = await fileExists(path);
  if (!exists) {
    if (isCI() && !update) {
      return {
        pass: false,
        message: () => `No committed PDF baseline at ${path}. Run the test locally to create it, then commit the baseline.`
      };
    }
    await writeSnapshotFile(path, snapshot);
    return { pass: true, message: () => `Wrote new PDF baseline at ${path}` };
  }
  if (update) {
    await writeSnapshotFile(path, snapshot);
    return { pass: true, message: () => `Updated PDF baseline at ${path}` };
  }
  const baseline = await readSnapshotFile(path);
  const result = diffSnapshots(baseline, snapshot, opts);
  const blocking = result.events.filter((e) => e.severity !== "info");
  const pass = blocking.length === 0;
  return {
    pass,
    message: () => pass ? "PDF snapshot matched" : formatFailure(result.events, path)
  };
}
async function toSnapshot(received) {
  if (isSnapshot(received))
    return received;
  if (isLayoutInfo(received))
    return fromFormeLayout(received);
  if (received instanceof Uint8Array)
    return fromPdf(received);
  if (received instanceof ArrayBuffer)
    return fromPdf(new Uint8Array(received));
  if (isPathInput(received)) {
    if (received.path.endsWith(".json"))
      return readSnapshotFile(received.path);
    const bytes = await readFile2(received.path);
    return fromPdf(new Uint8Array(bytes));
  }
  throw new Error("toMatchPDFSnapshot: unsupported input. Pass a PDF (Uint8Array/ArrayBuffer), a FormePDF LayoutInfo, a StructuralSnapshot, or { path }.");
}
function isSnapshot(value) {
  return isObject(value) && "contentHash" in value && "nodes" in value && "version" in value;
}
function isLayoutInfo(value) {
  if (!isObject(value) || !("pages" in value))
    return false;
  const pages = value.pages;
  if (!Array.isArray(pages))
    return false;
  return pages.length === 0 || isObject(pages[0]) && "elements" in pages[0];
}
function isPathInput(value) {
  return isObject(value) && typeof value.path === "string";
}
function isObject(value) {
  return typeof value === "object" && value !== null;
}
async function fileExists(path) {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

// packages/vitest/src/index.ts
expect.extend({
  async toMatchPDFSnapshot(received, options = {}) {
    const state = expect.getState();
    const snapshotState = state.snapshotState;
    const outcome = await assertMatchesPDFSnapshot(received, {
      testPath: state.testPath ?? "",
      currentTestName: state.currentTestName ?? "snapshot",
      snapshotName: options.snapshotName,
      updateMode: snapshotState?._updateSnapshot === "all"
    }, options);
    return { pass: outcome.pass, message: outcome.message };
  }
});
