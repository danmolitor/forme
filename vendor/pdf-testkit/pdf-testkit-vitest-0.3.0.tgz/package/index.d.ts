export interface PdfSnapshotOptions {
  snapshotDir?: string;
  snapshotName?: string;
  minConfidence?: number;
  positionThresholdPts?: number;
  ignoreRoles?: string[];
  severityOverrides?: Record<string, 'info' | 'warn' | 'error'>;
}
interface PdfMatchers<R = unknown> {
  toMatchPDFSnapshot(options?: PdfSnapshotOptions): Promise<R>;
}
declare module 'vitest' {
  interface Assertion<T = any> extends PdfMatchers<T> {}
  interface AsymmetricMatchersContaining extends PdfMatchers {}
}
export {};
